/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obligatorio;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Tomas
 */
public class Partida {

    private int contador;
    private int filasYCol;
    private int[][] tablero;
    private String hora;
    private int numeroDePartida;
    private String ganador;
    private int puntajeJugadorUno;
    private int puntajeJugadorDos;

    public Partida() {
        this.filasYCol = 6;
        this.tablero = new int[filasYCol][filasYCol];
    }

    public static void ingresarJugadores(Jugador instanciaUno, Jugador instanciaDos) {
        Jugador jugadorUno = instanciaUno;
        Jugador jugadorDos = instanciaDos;
    }

    public static void horaJugada(String[] args) {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("HH:mm:ss");
        // "dd-MM-yyyy HH:mm:ss" formato con fecha
        String formatDateTime = now.format(format);
        System.out.println("Hora de la jugada: " + formatDateTime);
    }

    public int getFilasYCol() {
        return this.filasYCol;
    }
    
    public void vaciarTablero(){
        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero.length; j++) {
                tablero[i][j] = 1;
                
            }
            
        }
    }

    public int[][] getTablero() {
        return this.tablero;
    }

    public void setNumeroDePartida(int numeroDePartida) {

        this.numeroDePartida = numeroDePartida;
    }

    public int getNumeroDePartida() {
        return this.numeroDePartida;
    }

    public void setGanador(String ganador) {
        this.ganador = ganador;
    }

    public String getGanador() {
        return this.ganador;
    }

    public void setPuntajeRojo(int puntajeJugadorUno) {
        this.puntajeJugadorUno = puntajeJugadorUno;
    }

    public int getPuntajeRojo() {
        return this.puntajeJugadorUno;
    }

    public void setPuntajeAzul(int puntajeJugadorDos) {
        this.puntajeJugadorDos = puntajeJugadorDos;
    }

    public int getPuntajeAzul() {
        return this.puntajeJugadorDos;
    }

    public int contadorRecursivo(Boolean[][] matriz, int contadorTemporal, int i, int j) {
        contadorTemporal++;
        matriz[i][j] = FALSE;
        if (matriz[i][j + 1] == TRUE) {
            contadorRecursivo(matriz, contadorTemporal, i, j + 1);
        }
        if (matriz[i - 1][j] == TRUE) {
            contadorRecursivo(matriz, contadorTemporal, i - 1, j);
        }
        if (matriz[i][j - 1] == TRUE) {
            contadorRecursivo(matriz, contadorTemporal, i, j - 1);
        }
        if (matriz[i + 1][j] == TRUE) {
            contadorRecursivo(matriz, contadorTemporal, i + 1, j);
        }
        return contadorTemporal;
    }

    public int calcularMaximo(int[][] tablero, int indice) {
        Boolean[][] matrizIslas = new Boolean[6][6];
        int max = 0;
        for (int i = 0; i < matrizIslas.length; i++) {
            for (int j = 0; j < matrizIslas.length; j++) {
                if (tablero[i][j] == indice) {
                    matrizIslas[i][j] = TRUE;
                }
            }
        }
        for (int i = 0; i < matrizIslas.length; i++) {
            for (int j = 0; j < matrizIslas.length; j++) {
                if (matrizIslas[i][j]) {
                    int tamañoIslas = contadorRecursivo(matrizIslas, 0, i, j);
                    if (tamañoIslas > max) {
                        max = tamañoIslas;
                    }
                }
            }

        }
        return max;
    }

    public void calcularPuntajeActual() {
        puntajeJugadorUno = calcularMaximo(tablero, 1);
        puntajeJugadorDos = calcularMaximo(tablero, 2);
        System.out.println("Puntaje Rojo " + puntajeJugadorUno + ", Puntaje Azul " + puntajeJugadorDos);
    }

    public String calcuarGanador() {
        if (puntajeJugadorUno > puntajeJugadorDos) {
            ganador = "Jugador 2 con " + puntajeJugadorDos + " puntos.";
        } else {
            ganador = "Jugador 2 con " + puntajeJugadorDos + " puntos.";
        }
        return ganador;
    }
}
