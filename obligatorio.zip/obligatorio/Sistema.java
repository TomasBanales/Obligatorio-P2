/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obligatorio;

import java.util.ArrayList;

/**
 *
 * @author Tomas
 */
public class Sistema {

    //lista de partidas y jugdores
    public int contadorDePartidas;
    ArrayList<Partida> listaPartidas = new ArrayList();
    ArrayList<Jugador> listaJugadores = new ArrayList();

    private void guardarPartida(Partida instanciaDePartida) {
        listaPartidas.add(instanciaDePartida);
    }

    private void guardarJugadores(Jugador instanciaUno, Jugador instanciaDos) {
        listaJugadores.add(instanciaUno);
        listaJugadores.add(instanciaDos);
    }
}
