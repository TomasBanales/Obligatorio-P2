package obligatorio;

/*
Juan Rodríguez 225931
Tomás Bañales 239825
 */
public class Obligatorio {

    public static void main(String[] args) {
//             Obligatorio.registroUsuario(args);
        Partida.horaJugada(args);
        Partida p1 = new Partida();

        //pedir jugadores
//        System.out.println(p1.getHora());
//        Jugador J1 = new Jugador("Tomas", 18);
        int[][] tablero1 = p1.getTablero();
        p1.vaciarTablero();
        mostrarTablero(p1);

    }

    public static void mostrarTablero(Partida instancia) {
        int filas = instancia.getFilasYCol();
        int[][] tablero = instancia.getTablero();
        for (int i = 0; i < 19; i++) {
            for (int j = 0; j < 20; j++) {
                if (i <= 2 && j <= 18) {
                    System.out.print("\u001B[43m^");
                } else if (i > 2 && i < 16) {
                    if (j > 3 && j <= 17 && (i % 2) != 0) {
                        if ((j % 2) == 0 && j <= 17) {
                            if(i == 3 || i == 15){
                                System.out.print("\u001B[42m+");
                            }
                            else if(j == 4 || j == 16){
                                System.out.print("\u001B[42m+");
                            }
                            else {
                                System.out.print("\u001B[0m+");
                            }
                        } else if ((j % 2) != 0 && j <= 15) {
                            if(i == 3 || i == 15){
                                System.out.print("\u001B[42m-");
                            }
                            else {
                                System.out.print("\u001B[0m-");
                            }
                        }

                    } else if ((i % 2) == 0) {
                        if ((j % 2) != 0 && j > 3 && j <= 17) {
                            if (j == 5 || j == 17) {
                                System.out.print("\u001B[42m|");
                            } else {
                                System.out.print("\u001B[0m|");
                            }
                        } else if ((j % 2) == 0 && j > 4 && j <= 16) {
                            System.out.print(tablero[((i-4)/2)][((j-4)/2)]);
                        }
                    }
                } else if (i >= 16 && j <= 18) {
                    System.out.print("\u001B[45mU");
                }
                if (i > 2 && i < 16 && j <= 2) {
                    System.out.print("\u001B[41mC");
                }
                if (i > 2 && i < 16 && j > 16) {
                    System.out.print("\u001B[46mT");
                }

            }
            System.out.println();
        }
    }
}
